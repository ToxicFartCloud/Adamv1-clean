# Runbook
**Offline-only. Do not edit Adam.py. New code must be in `plugins/` or `sidecars/`.**

## Execution Contract
- Deterministic outputs: set random seeds where relevant and avoid non-deterministic operations.
- All file paths MUST be absolute (project-root anchored) and printed explicitly.
- Provide unit tests where applicable and ensure repeatable results.
- NEVER request or use cloud services, online APIs, or paid keys. Local-only.

## Work Style
- Respond with a single, linear plan followed by exact file diffs/creations.
- For each file you create or modify, output a fenced code block with the full content and the absolute path header.
- After generating files, run tests and print a short, deterministic summary.
- Keep logging in JSON (one object per line) where requested.

## Project Root Assumptions
- Project root is the current working directory (cwd) where `npx gemini` is invoked.
- Paths like `adam_tools/...`, `config/...`, `docs/...`, `tests/...`, `sidecars/...`, and `logs/...` are created relative to cwd.
- Python package root for tools is `adam_tools/`.
- Python version is 3.10+; no external network access.

---
# 03 — Startup Self-Audit Sidecar (Audit & Adaptation)

## Objective
Provide a **sidecar** service that audits local HW/SW and proposes offline adaptation plans. A tiny client plugin should call the sidecar for actions.

## Required Deliverables
1. `/absolute/path/to/project/sidecars/audit/app.py` with endpoints:
   - `POST /audit/run` → perform audit now and return full report JSON.
   - `GET  /audit/capabilities` → current capability map (CPU/GPU flags, RAM, drivers, Python, libs, local models).
   - `POST /adapt/plan` → accept a goal and return a concrete plan (batch size, quant level, model choice 14B vs 30B, etc.).
   - `POST /adapt/apply?dry_run=1` → simulate plan; if `dry_run=0`, require explicit approval hook.
2. `/absolute/path/to/project/sidecars/audit/capabilities.py` for capability probes.
3. `/absolute/path/to/project/sidecars/audit/playbooks.py` mapping capability → actions.
4. `/absolute/path/to/project/adam_tools/plugins/audit_client/__init__.py` with `run(action, dry_run=True)` to call sidecar.
5. `/absolute/path/to/project/docs/AUDIT_ADAPTATION.md` documenting workflows.
6. `/absolute/path/to/project/tests/test_audit_sidecar.py` covering endpoints and dry-run flow.

## Safety & Logging
- `dry_run` required by default; **no changes** without approval.
- Every apply must record a rollback plan and write JSON logs to `logs/sidecars/audit.log`.

## Acceptance
- `/audit/capabilities` returns a stable capability map structure.
- `/adapt/plan` returns a deterministic plan for the same inputs.
- `/adapt/apply?dry_run=1` runs without altering the system and returns a preview; tests pass.

## Actions
1. Create files above with complete, offline-only implementations.
2. Print absolute paths created.
3. Run tests and print summary.