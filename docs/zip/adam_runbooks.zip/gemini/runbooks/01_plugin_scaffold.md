# Runbook
**Offline-only. Do not edit Adam.py. New code must be in `plugins/` or `sidecars/`.**

## Execution Contract
- Deterministic outputs: set random seeds where relevant and avoid non-deterministic operations.
- All file paths MUST be absolute (project-root anchored) and printed explicitly.
- Provide unit tests where applicable and ensure repeatable results.
- NEVER request or use cloud services, online APIs, or paid keys. Local-only.

## Work Style
- Respond with a single, linear plan followed by exact file diffs/creations.
- For each file you create or modify, output a fenced code block with the full content and the absolute path header.
- After generating files, run tests and print a short, deterministic summary.
- Keep logging in JSON (one object per line) where requested.

## Project Root Assumptions
- Project root is the current working directory (cwd) where `npx gemini` is invoked.
- Paths like `adam_tools/...`, `config/...`, `docs/...`, `tests/...`, `sidecars/...`, and `logs/...` are created relative to cwd.
- Python package root for tools is `adam_tools/`.
- Python version is 3.10+; no external network access.

---
# 01 — Plugin Scaffold (No changes to Adam.py)

## Objective
Add a minimal plugin framework **without touching `Adam.py`**. The framework must allow discovery, registration, and invocation of plugins with a consistent return schema.

## Constraints
- Return shape is a dict: `{"ok": bool, "data": any, "error": str|None}`.
- Plugins may log JSON lines to `logs/plugins/*.log`. Each line: one JSON object with timestamp, plugin, event, payload.
- Configuration must load from `config/plugins.yaml` if present; otherwise use sane defaults.
- Offline-only. No internet. No cloud keys.

## Required Deliverables (Create these exact files)
1. `/absolute/path/to/project/adam_tools/plugins/README.md` — plugin spec and usage.
2. `/absolute/path/to/project/adam_tools/plugins/registry.yaml` — registry with `name`, `version`, `entrypoint`, `enabled`.
3. `/absolute/path/to/project/adam_tools/plugins/base.py` — `Plugin` ABC, `load_plugins`, `call_plugin`.
4. `/absolute/path/to/project/adam_tools/plugins/example_echo/__init__.py` — `run(text)->{ok,data,error}` echo implementation.
5. `/absolute/path/to/project/tests/test_plugins_scaffold.py` — tests.
6. `/absolute/path/to/project/docs/PLUGINS_GUIDE.md` — docs for devs.

## Implementation Notes
- Plugin entrypoints are import paths like `adam_tools.plugins.example_echo` exposing a `run(**kwargs)` function.
- `load_plugins()` reads `adam_tools/plugins/registry.yaml` and yields enabled plugins.
- `call_plugin(name, params)` resolves by name, imports module, and calls `run(**params)`; exceptions are caught and returned as `ok=False` with `error` string.
- JSON logs to `logs/plugins/{plugin_name}.log`. Include ISO8601 timestamp and a stable event name.
- All paths must be absolute in your output; compute with `os.path.abspath` when printing.

## Acceptance Criteria
- `call_plugin("example_echo", {"text": "hi"})` returns `{"ok": true, "data": "hi", "error": null}`.
- Tests pass via `pytest -q` with deterministic output.

## Actions
1. Create folders and files listed above with full contents.
2. Print the absolute paths created.
3. Run `pytest -q` and print summary.
4. Show a short demo call for `example_echo` using Python (no network).