# Runbook
**Offline-only. Do not edit Adam.py. New code must be in `plugins/` or `sidecars/`.**

## Execution Contract
- Deterministic outputs: set random seeds where relevant and avoid non-deterministic operations.
- All file paths MUST be absolute (project-root anchored) and printed explicitly.
- Provide unit tests where applicable and ensure repeatable results.
- NEVER request or use cloud services, online APIs, or paid keys. Local-only.

## Work Style
- Respond with a single, linear plan followed by exact file diffs/creations.
- For each file you create or modify, output a fenced code block with the full content and the absolute path header.
- After generating files, run tests and print a short, deterministic summary.
- Keep logging in JSON (one object per line) where requested.

## Project Root Assumptions
- Project root is the current working directory (cwd) where `npx gemini` is invoked.
- Paths like `adam_tools/...`, `config/...`, `docs/...`, `tests/...`, `sidecars/...`, and `logs/...` are created relative to cwd.
- Python package root for tools is `adam_tools/`.
- Python version is 3.10+; no external network access.

---
# 02 — Agent Memory Plugin (STM + pgvector LTM)

## Objective
Build a memory plugin exposing `write`, `search`, `summarize`, and `consolidate` that runs locally using a **local embeddings model** (e.g., Embedding Gemma via Ollama or a local Python implementation). Provide vector search with cosine similarity and rerank by `score * (recency^α) * (importance^β)`.

## Requirements
- Module path: `adam_tools/plugins/memory/__init__.py` with callable `run(action, **kwargs)` that dispatches to sub-ops.
- Provide schema and init SQL at `adam_tools/plugins/memory/schema.sql` for Postgres + pgvector. Include table(s) for items, embeddings, metadata (timestamp, importance, source, tokens, etc.).
- Provide `config/plugins.memory.yaml` for tunables (α, β, token caps, stm_window, embed_model path/name).
- Provide `adam_tools/plugins/memory/README.md` with setup for local-only operation, including optional SQLite fallback using a local cosine index (no pgvector required) if Postgres is absent.
- JSON logs to `logs/plugins/memory.log` (one JSON object per line with op, duration, counts).
- Deterministic summarization respecting token cap (truncate deterministically by tokens/characters, stable order).

## Required Deliverables
1. `/absolute/path/to/project/adam_tools/plugins/memory/__init__.py`
2. `/absolute/path/to/project/adam_tools/plugins/memory/schema.sql`
3. `/absolute/path/to/project/adam_tools/plugins/memory/README.md`
4. `/absolute/path/to/project/config/plugins.memory.yaml`
5. `/absolute/path/to/project/tests/test_memory_plugin.py`

## Search & Ranking
- Use cosine similarity for initial retrieval (top-k).
- Rerank by: `final = cosine * (recency_seconds + 1) ** α * (importance + 1) ** β` with α, β from config.
- Return structured results: `{"ok": true, "data": {"matches": [{"text": "...", "score": 0.0, "metadata": {...}}], "query": "..."} , "error": null}`.
- Include `citations` referencing stored `id` and source when present.

## Acceptance
- Write three facts; a subsequent `search` returns them with non-zero scores and citations.
- `summarize` respects `token_cap` from config and is deterministic.
- All tests pass via `pytest -q`.

## Actions
1. Implement plugin with local embedding calls; if the model isn't available, implement a deterministic hashing embedder fallback.
2. Create and print absolute paths to all deliverables.
3. Run tests and print the summary.