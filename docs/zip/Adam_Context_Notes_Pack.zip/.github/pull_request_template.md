## Context (why)
- Summary:
- User goal:
- Offline-only impact: ☐ none ☐ updated config ☐ changed models

## Links
- ADR: ADR-XXXX-<slug> (or n/a)
- Context Note: docs/context/<feature>/CONTEXT.md (or n/a)

## Changes
- What changed (bullets):
- Rollback plan:

## Checks
- [ ] No cloud/API calls introduced
- [ ] Logs/metrics updated if needed
- [ ] Eval impact considered or added to backlog
