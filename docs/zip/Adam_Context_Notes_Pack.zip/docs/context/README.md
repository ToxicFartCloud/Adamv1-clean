# Context Notes (Lightweight) — Adam

Purpose: keep the *why* close to the code so future workers/models understand decisions.

## When to write what
- **ADR (Architecture Decision Record):** cross-cutting or irreversible choices (models, storage, routing, security).
- **Context Note:** feature/module-level intent and constraints (1 page max).
- **PR Template:** summary + link to ADR/context; rollbacks; offline-only check.

## Quick rules
1) Keep each ADR to 1 page; link from PRs and code comments as `ADR:<id>`.
2) Put one **Context Note** per feature in `docs/context/<feature>/CONTEXT.md`.
3) Update `DECISIONS.md` with a single line when an ADR merges.
4) No cloud/API keys; offline-only impacts must be called out.

## File map
- `DECISIONS.md` — chronological index (1-liners)
- `ADR-0001-template.md` — copy/rename to `ADR-XXXX-<slug>.md`
- `Context-Note-template.md` — copy into `docs/context/<feature>/CONTEXT.md`
- `.github/pull_request_template.md` — PR checklist wired to ADR/Context
