# ADR-0001: <Title>

- **Status:** Proposed | Accepted | Superseded
- **Date:** YYYY-MM-DD
- **Owners:** <names>
- **Scope:** <code areas / services>
- **Models impacted:** <e.g., Qwen2.5-14B, Qwen3-30B>
- **Tags:** [offline-only], [security], [performance], [memory], [router]

## Context (Why)
<What problem are we solving? User goals, constraints, offline-only notes.>

## Options considered
1) <Option A>
2) <Option B>
3) <Option C>

## Decision
<What we chose and why it fits Adam.>

## Consequences
- Positive:
- Negative:
- Rollback plan:

## Links
- Related PRs:
- Context Notes:
- Experiments/benchmarks:
