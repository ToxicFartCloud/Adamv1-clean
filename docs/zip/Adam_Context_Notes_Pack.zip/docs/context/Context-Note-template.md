# Context Note — <Feature/Module>

- **File/Path:** <e.g., api/routers/ask.py>
- **User goal:** <what this enables>
- **Assumptions:** <models, data, constraints>
- **Key behaviors:** <bullets; inputs → outputs>
- **Offline-only:** <confirm no cloud/API keys>
- **Eval impact:** <what metrics move>
- **Open questions:** <bullets>
- **Related ADRs:** ADR-XXXX-<slug>

> Keep it to one page. Update when behavior or assumptions change.
