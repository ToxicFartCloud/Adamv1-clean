# Decisions Index (1-liners)

> Add one line per ADR when merged. Keep details in the ADR.

- 2025-09-16 • Initialized Context Notes system (ADR/Context/PR template).
